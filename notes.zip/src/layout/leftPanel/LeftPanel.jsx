import "./LeftPanel.css";

export function LeftPanel({ children }) {
  return <div className="left-panel">{children}</div>;
}
