import { useState } from "react";
import "./App.css";
import { LeftPanel } from "./layout/leftPanel/LeftPanel";
import Body from "./layout/body/Body";
import Header from "./components/Header/Header";
import JournalAddBtn from "./components/JournalAddBtn/JournalAddBtn";
import JournalList from "./components/JournalList/JournalList";
import JournalForm from "./components/JournalForm/JournalFormReducer";

function App() {
  const [count, setCount] = useState(0);
  const data = [
    {
      title: "Подготовка к обновлению курсов 1",
      date: new Date(),
      text: "Горные походы открывают удивительные природные ландшафты, испытывают туристов физически и морально, дают возможность почувствовать себя первопроходцем",
    },
    {
      title: "Подготовка к обновлению курсов 2",
      date: new Date(),
      text: "Горные походы открывают удивительные природные ландшафты, испытывают туристов физически и морально, дают возможность почувствовать себя первопроходцем",
    },
    {
      title: "Подготовка к обновлению курсов 3",
      date: new Date(),
      text: "Горные походы открывают удивительные природные ландшафты, испытывают туристов физически и морально, дают возможность почувствовать себя первопроходцем",
    },
  ];

  return (
    <div className="app">
      <LeftPanel>
        <Header />
        <JournalAddBtn />
        <JournalList items={data} />
      </LeftPanel>
      <Body>
        <JournalForm />
      </Body>
    </div>
  );
}

export default App;
