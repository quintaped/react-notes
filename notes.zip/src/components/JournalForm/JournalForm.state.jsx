export const INITIAL_STATE = {
  isFormReadyToSubmit: false,
  values: {
    title: "",
    data: "",
    tag: "",
    text: "",
  },
  isValid: { title: true, data: true, text: true },
};
export function formReducer(state, action) {
  switch (action.type) {
    case "CLEAR_FORM":
      return {
        ...state,
        isFormReadyToSubmit: false,
        values: INITIAL_STATE.values,
      };
    case "RESET_VALIDITY":
      return {};
    case "SUBMIT": {
      console.log(state.values);
      const titleValidity = state.values.title?.trim().length;
      const dataValidity = state.values.data;
      const textValidity = state.values.text?.trim().length;
      return {
        ...state,
        isValid: {
          title: titleValidity,
          data: dataValidity,
          text: textValidity,
        },
        isFormReadyToSubmit: titleValidity && dataValidity && textValidity,
      };
    }
    case "SET_VALUE":
      return {
        ...state,
        values: {
          ...state.values,
          ...action.payload,
        },
      };
    case "SET_FORM":
      return {};
  }
}
