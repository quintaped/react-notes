import CardBtn from "../CardBtn/CardBtn";
import JournalItem from "../JournalItem/JournalItem";
import styles from "./JournalList.module.css";

const JournalList = ({ items }) => {
  return (
    <div className={styles["journal-list"]}>
      {items.map((item, index) => (
        <CardBtn key={item.index}>
          <JournalItem {...item}></JournalItem>
        </CardBtn>
      ))}
    </div>
  );
};
export default JournalList;
